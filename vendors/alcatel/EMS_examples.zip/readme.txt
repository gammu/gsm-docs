This directory contains examples of downloads to an Alcatel mobile using the EMS protocol.

Note that for readibility purpose, all examples are provided in hex format. However, the actual data sent to the mobile has to be in binary format.