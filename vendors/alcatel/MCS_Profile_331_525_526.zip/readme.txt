To install the new profile for One Touch 331, One Touch 525 and One Touch 526:

Put the OT331-525-526.xml file in the Profiles directory located in the 
Multimedia Conversion Studio directory.
By default in Program files/AlcatelOne Touch (tm) directory